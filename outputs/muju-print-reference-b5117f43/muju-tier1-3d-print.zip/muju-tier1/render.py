"""Render the exported STL parts with Blender; no remodeling or generated imagery.

blender --background --factory-startup --python render.py
"""
import json
import math
from pathlib import Path

import bpy
from mathutils import Vector

HERE = Path(__file__).resolve().parent
manifest = json.loads((HERE / 'manifest.json').read_text())
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)


def linear(c):
    return c / 12.92 if c < .04045 else ((c + .055) / 1.055) ** 2.4


def material(name, color):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    color = tuple(linear(int(color[i:i + 2], 16) / 255) for i in (1, 3, 5)) + (1,)
    shader = m.node_tree.nodes.get('Principled BSDF')
    shader.inputs['Base Color'].default_value = color
    shader.inputs['Roughness'].default_value = .37
    m.diffuse_color = color
    return m


materials = {k: material(k, v['hex']) for k, v in manifest['palette'].items()}
for row in manifest['tokens']:
    column = list(manifest['palette'])[2:].index(row['element'])
    for part, color in [('base', row['owner']), ('details', row['element'])]:
        bpy.ops.wm.stl_import(filepath=str(HERE / 'files/parts' / f'{row["key"]}_{part}.stl'))
        obj = bpy.context.object
        obj.name = f'{row["key"]}_{part}'
        obj.location = ((column - 2.5) * 36, 22 if row['owner'] == 'black' else -22, 0)
        obj.data.materials.append(materials[color])
        # Mesh normals stay flat: the render shows the actual exported surface.

bpy.ops.mesh.primitive_plane_add(size=2000, location=(0, 0, -.03))
floor = bpy.context.object
floor.name = 'Display floor - not a printable part'
floor.data.materials.append(material('Background', '#E8ECEF'))


def point_at(obj, target):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat('-Z', 'Y').to_euler()


bpy.ops.object.camera_add(location=(0, -155, 245))
camera = bpy.context.object
point_at(camera, (0, 0, 0))
camera.data.type = 'ORTHO'
camera.data.ortho_scale = 226
bpy.context.scene.camera = camera

for loc, power, size in [((-75, -65, 170), 330000, 100), ((90, 40, 100), 230000, 90)]:
    bpy.ops.object.light_add(type='AREA', location=loc)
    light = bpy.context.object
    light.data.energy = power
    light.data.shape = 'DISK'
    light.data.size = size
    point_at(light, (0, 0, 0))

scene = bpy.context.scene
scene.unit_settings.system = 'METRIC'
scene.unit_settings.scale_length = .001
scene.render.engine = 'CYCLES'
scene.cycles.device = 'CPU'
scene.cycles.samples = 40
scene.cycles.use_denoising = True
scene.world.use_nodes = True
scene.world.node_tree.nodes['Background'].inputs[0].default_value = (.75, .8, .9, 1)
scene.world.node_tree.nodes['Background'].inputs[1].default_value = .45
scene.view_settings.view_transform = 'AgX'
scene.render.resolution_x = 1800
scene.render.resolution_y = 880
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.render.filepath = str(HERE / 'preview-render.png')
bpy.ops.render.render(write_still=True)
camera.location = (0, 0, 300)
point_at(camera, (0, 0, 0))
scene.render.filepath = str(HERE / 'preview-top.png')
bpy.ops.render.render(write_still=True)
