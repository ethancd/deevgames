import type { GameState, PlayerId, Position } from '../game/types';
import type { AIAction } from './types';
import { getUnitById, placeUnit } from '../game/board';
import { getNextTierDefinition, getUnitDefinition } from '../game/units';
import { resolveCombat } from '../game/combat';
import { executeMine } from '../game/mining';
import { completeUpkeep, useAction, endTurn, startActionPhase, startQueuePhase, canActInPlacePhase, canActInQueuePhase } from '../game/turn';
import { isLegalAction } from '../game/legality';
import { getMoveCost } from '../game/movement';
import { checkVictory } from '../game/victory';

/** Deterministic IDs keep the UI reducer and its AI shadow state in sync.
 * Uniqueness is checked against every live unit and queue (including saved games).
 */
function nextQueueId(state: GameState): string {
  const ids = new Set([...state.board.units.map(u => u.id), ...Object.values(state.players).flatMap(p => p.buildQueue.map(q => q.id))]);
  const prefix = `q-${state.turn.currentPlayer}-${state.turn.turnNumber}-`;
  let n = 0;
  while (ids.has(prefix + n) || ids.has('unit-' + prefix + n)) n++;
  return prefix + n;
}

/** Authoritative immutable transition, used by real play AND search.
 * Rejected actions return the original object without charging an action/resource.
 */
export function applyAction(state: GameState, action: AIAction): GameState {
  if (!isLegalAction(state, action)) return state;
  const next = applyLegalAction(state, action);
  return next === state ? state : { ...next, selectedUnit: null, validMoves: [], validAttacks: [] };
}

function applyLegalAction(state: GameState, action: AIAction): GameState {
  switch (action.type) {
    case 'PAY_UPKEEP': return completeUpkeep(state,action.keepUnitIds);
    case 'MOVE':
      return applyMove(state, action.unitId, action.to);

    case 'ATTACK':
      return applyAttack(state, action.unitId, action.targetPosition);

    case 'MINE':
      return applyMine(state, action.unitId);

    case 'END_PLACE_PHASE':
      return startActionPhase(state);

    case 'END_ACTION_PHASE':
      return startQueuePhase(state);

    case 'END_TURN':
      return endTurn(state);

    case 'QUEUE_UNIT':
      return applyQueueUnit(state, action.definitionId);

    case 'PLACE_UNIT':
      return finishPlacement(applyPlaceUnit(state, action.queuedUnitId, action.position));

    case 'PROMOTE_UNIT':
      return finishPlacement(applyPromoteUnit(state, action.unitId));

    case 'RESIGN':
      return applyResign(state);

    default:
      return state;
  }
}

function applyResign(state: GameState): GameState {
  const winner = state.turn.currentPlayer === 'white' ? 'black' : 'white';
  return {
    ...state,
    phase: 'victory',
    winner,
    victoryReason: 'resignation',
  };
}

function applyMove(state: GameState, unitId: string, to: Position): GameState {
  const newBoard = {
    ...state.board,
    units: state.board.units.map((u) =>
      u.id === unitId ? { ...u, position: to, hasMoved: true } : u
    ),
  };

  const unit = getUnitById(state.board, unitId)!;
  const cost = getMoveCost(unit.position, to, getUnitDefinition(unit.definitionId).speed, state.board)!;
  let newState = state;
  for (let i = 0; i < cost; i++) newState = useAction(newState);
  return { ...newState, board: newBoard };
}

function applyAttack(state: GameState, unitId: string, targetPosition: Position): GameState {
  const { board: newBoard } = resolveCombat(state.board, unitId, targetPosition);
  const killed = newBoard.units.filter(u => u.owner !== state.turn.currentPlayer).length < state.board.units.filter(u => u.owner !== state.turn.currentPlayer).length;
  const newState = useAction(killed ? {...state,inactivityPlies:0,progressThisTurn:true} : state);

  // Check victory
  const victory = checkVictory(newBoard);
  if (victory.status === 'victory') {
    return {
      ...newState,
      board: newBoard,
      phase: 'victory',
      winner: victory.winner,
      victoryReason: 'elimination',
    };
  }

  return { ...newState, board: newBoard };
}

function applyMine(state: GameState, unitId: string): GameState {
  const unit = getUnitById(state.board, unitId);
  if (!unit) return state;

  const currentPlayer = unit.owner;
  const currentResources = state.players[currentPlayer].resources;
  const { board: newBoard, newResources, amountMined } = executeMine(
    state.board,
    unitId,
    currentResources
  );

  if (amountMined === 0) return state;

  const newPlayers = {
    ...state.players,
    [currentPlayer]: {
      ...state.players[currentPlayer],
      resources: newResources,
      resourcesGained: state.players[currentPlayer].resourcesGained + amountMined,
    },
  };

  const newState = useAction(state);
  return { ...newState, board: newBoard, players: newPlayers, inactivityPlies:0, progressThisTurn:true };
}

function finishPlacement(state: GameState): GameState {
  return canActInPlacePhase(state, state.turn.currentPlayer) ? state : startActionPhase(state);
}

function applyQueueUnit(state: GameState, definitionId: string): GameState {
  const def = getUnitDefinition(definitionId);
  const currentPlayer = state.turn.currentPlayer;
  const playerState = state.players[currentPlayer];

  if (playerState.resources < def.cost) {
    return state;
  }

  const queuedUnit = {
    id: nextQueueId(state),
    definitionId,
    turnsRemaining: def.buildTime,
    owner: currentPlayer,
  };

  const next = {
    ...state,
    players: {
      ...state.players,
      [currentPlayer]: {
        ...playerState,
        resources: playerState.resources - def.cost,
        resourcesSpent: playerState.resourcesSpent + def.cost,
        buildQueue: [...playerState.buildQueue, queuedUnit],
      },
    },
  };
  return canActInQueuePhase(next, currentPlayer) ? next : endTurn(next);
}

function applyPlaceUnit(state: GameState, queuedUnitId: string, position: Position): GameState {
  const currentPlayer = state.turn.currentPlayer;
  const playerState = state.players[currentPlayer];

  const queuedUnit = playerState.buildQueue.find((u) => u.id === queuedUnitId);
  if (!queuedUnit) return state;

  const def = getUnitDefinition(queuedUnit.definitionId);

  // Create the new unit
  const newUnit = {
    id: `unit-${queuedUnit.id}`,
    definitionId: queuedUnit.definitionId,
    owner: currentPlayer,
    position,
    hasMoved: false,
    hasAttacked: false,
    lastAttackKilled: false,
    hasMined: false,
    canActThisTurn: true, // Can act immediately (no summoning sickness)
    damageTaken: 0,
    promotedThisPlacement: false,
    placedThisTurn: true, // Can't be promoted on the same turn it's placed
  };

  const newBoard = placeUnit(state.board, newUnit);

  // Remove from queue, update resourcesSpent
  const newQueue = playerState.buildQueue.filter((u) => u.id !== queuedUnitId);

  return {
    ...state,
    board: newBoard,
    players: {
      ...state.players,
      [currentPlayer]: {
        ...playerState,
        buildQueue: newQueue,
        resourcesManifested: playerState.resourcesManifested + def.cost,
      },
    },
  };
}

function applyPromoteUnit(state: GameState, unitId: string): GameState {
  const unit = getUnitById(state.board, unitId);
  if (!unit) return state;

  // Check if placed this turn (can't promote same turn as placement)
  if (unit.placedThisTurn) return state;

  // Check if already promoted this placement phase
  if (unit.promotedThisPlacement) return state;

  const currentPlayer = unit.owner;
  const playerState = state.players[currentPlayer];
  const def = getUnitDefinition(unit.definitionId);


  // Find next tier unit of same element
  const nextTierDef = getNextTierDefinition(def.id);
  if (!nextTierDef) return state;
  // Promotion cost is the difference between next tier and current tier costs
  const promotionCost = nextTierDef.cost - def.cost;

  if (playerState.resources < promotionCost) return state;

  const newBoard = {
    ...state.board,
    units: state.board.units.map((u) =>
      u.id === unitId
        ? { ...u, definitionId: nextTierDef.id, promotedThisPlacement: true }
        : u
    ),
  };

  return {
    ...state,
    board: newBoard,
    players: {
      ...state.players,
      [currentPlayer]: {
        ...playerState,
        resources: playerState.resources - promotionCost,
        resourcesSpent: playerState.resourcesSpent + promotionCost,
        resourcesManifested: playerState.resourcesManifested + promotionCost,
      },
    },
  };
}

/**
 * Apply a sequence of actions
 */
export function applyActions(state: GameState, actions: AIAction[]): GameState {
  let currentState = state;
  const player = state.turn.currentPlayer;
  for (const action of actions) {
    if (currentState.turn.currentPlayer !== player || !isLegalAction(currentState, action)) break;
    currentState = applyAction(currentState, action);
  }
  return currentState;
}

/**
 * Check if the game is in a terminal state
 */
export function isTerminal(state: GameState): boolean {
  return state.phase === 'victory' || checkVictory(state.board).status !== 'ongoing';
}

/**
 * Get the opponent player
 */
export function getOpponent(player: PlayerId): PlayerId {
  return player === 'white' ? 'black' : 'white';
}
