# Tier 1 print package completion

Request: six flat raised-art Tier 1 elements for both White and Black, with
white/black filament bases and element-colored filament relief. Generic slicer
files; no printer was specified.

Sources: current `units.ts`, `UnitArtwork.tsx`, `ElementGlyph.tsx` and site CSS.
The exact source commit and SHA-256 hashes are in `manifest.json`. Existing
unrelated checkout edits were preserved. No canonical game file was edited.

Impact plan: `python3 tools/muju-content-dag.py plan --kind print` selects only
`printable-tokens`; prerequisites `catalogue` and `browser-ui` were read and
verified unchanged. The new surface and its upstream art/catalogue dependencies
are mapped in `content-dag.json` and `docs/CONTENT_DAG.md`.

Disposition: **changed** — `printable-tokens`. Added reproducible generation,
12 individual assembled pieces, 12 fused STLs, 24 aligned base/detail STLs,
individual/pair/team/full-set 3MFs, six-piece STL plates, renders and print guide.
The relief and pip deliberately share one element color. Dimensions are 30 mm
maximum body span, 3.2 mm base, 0.8 mm relief, 4 mm overall.

Verification:

- `build.py` passes: 38 re-imported STL files are watertight, consistently wound,
  positive-volume meshes with nondegenerate faces. All 12 fused tokens are single
  connected solids; plate files contain six separate tokens.
- 21 3MF files pass strict lib3mf 2.5.0 reads with zero warnings; their serialized
  meshes also pass validation and retain millimeter units and material indices.
- 20 horizontal sections per token are closed. Base/detail Z coordinates meet
  exactly at 3.2 mm. Union volume matches the sum of part volumes; there are no
  overlapping material volumes, air gaps, or unsupported relief footprints.
- Blender 5.1.1 renders the exported STL parts successfully. Angled and overhead
  images were inspected: all six symbols, both body silhouettes, leaf groove,
  chamfers, one pip per piece and palette are visible and intact.
- `package.py` verifies ZIP integrity and all archived model SHA-256 hashes.
- `python3 tools/muju-content-dag.py check`: valid, 28 nodes and 51 edges.
- `python3 tools/test-muju-content-dag.py`: all 14 existing tests pass.
- All three new Python scripts compile.

Blender incident: the initial sandboxed background launch crashed before running
Python (PID 24185, 2026-09-24 22:18:55 local time). Both user-supplied reports
describe that same process and timestamp. The authorized background launch and
final CPU renders outside the sandbox succeeded. Mesh generation and validation
use Python geometry libraries independently of Blender.

Limits: no physical print or printer-specific slicer test has been performed.
The 3MFs contain geometry and named preview materials, not machine profiles or
G-code. The README explains filament mapping and a manual layer-change fallback.

Rules, stats, saves, AI, Academy and deployed surfaces: verified unchanged in
scope; no deployment was requested or required. Remaining file-generation work:
none. First physical test print remains with the printer operator.
