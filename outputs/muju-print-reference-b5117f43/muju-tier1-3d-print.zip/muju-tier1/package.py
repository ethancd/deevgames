#!/usr/bin/env python3
"""Label the mesh render and package the printable files with their instructions."""
import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
manifest = json.loads((HERE / 'manifest.json').read_text())
font_path = Path('/System/Library/Fonts/Supplemental/Arial Unicode.ttf')
bold_path = Path('/System/Library/Fonts/Supplemental/Arial Bold.ttf')


def font(size, bold=False):
    chosen = bold_path if bold else font_path
    return ImageFont.truetype(str(chosen), size) if chosen.exists() else ImageFont.load_default(size=size)


render = Image.open(HERE / 'preview-render.png').convert('RGB')
sheet = Image.new('RGB', (1800, 1120), '#F4F5F6')
sheet.paste(render, (0, 150))
draw = ImageDraw.Draw(sheet)
draw.text((58, 32), 'MUJU / TIER 1', fill='#18222C', font=font(48, True))
draw.text((60, 99), 'Twelve printable tokens · white + black armies · six element colors',
          fill='#46535D', font=font(26))
for i, row in enumerate(manifest['tokens'][:6]):
    x = 900 + (i - 2.5) * (1800 / 226) * 36
    draw.text((x, 940), row['name'], fill='#192530', font=font(30), anchor='mt')
    draw.text((x, 985), row['element'].upper(), fill='#53616D', font=font(19, True), anchor='mt')
draw.text((60, 1060), '30 mm bodies / 4 mm tall / 0.8 mm raised symbols', fill='#334350', font=font(23))
draw.text((1740, 1060), 'Rendered from the exported meshes', fill='#63717C', font=font(20), anchor='rt')
sheet.save(HERE / 'preview.png')

archive = HERE / 'muju-tier1-3d-print.zip'
include = ['README.md', 'build.py', 'render.py', 'package.py', 'requirements.txt',
           'manifest.json', 'validation.json', 'COMPLETION.md', 'preview.png', 'preview-top.png']
with ZipFile(archive, 'w', ZIP_DEFLATED) as z:
    for name in include:
        z.write(HERE / name, f'muju-tier1/{name}')
    for path in sorted((HERE / 'files').rglob('*')):
        if path.is_file():
            z.write(path, f'muju-tier1/{path.relative_to(HERE)}')
with ZipFile(archive) as z:
    assert z.testzip() is None
    for path, expected in manifest['files'].items():
        assert hashlib.sha256(z.read(f'muju-tier1/{path}')).hexdigest() == expected
print(f'{archive}: {archive.stat().st_size:,} bytes; archive and model hashes verified.')
