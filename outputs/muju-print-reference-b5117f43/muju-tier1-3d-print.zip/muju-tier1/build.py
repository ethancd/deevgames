#!/usr/bin/env python3
"""Regenerate printable Tier 1 tokens from Muju's current SVG artwork.

Run with the packages in requirements.txt. All coordinates are millimeters.
Outputs are geometry, not printer-specific projects or machine instructions.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import lib3mf
import numpy as np
import trimesh
from shapely import affinity
from shapely.geometry import LineString, Polygon, box
from shapely.geometry.polygon import orient
from shapely.ops import unary_union
from svgpathtools import parse_path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OUT = HERE / 'files'
SIZE = 30.0
BASE_Z = 3.2
TOP_Z = 4.0
CORE = 'http://schemas.microsoft.com/3dmanufacturing/core/2015/02'
PALETTE = {
    'white': ('White base', '#F5F4EE'),
    'black': ('Black base', '#202329'),
    'fire': ('Fire - red', '#EF4444'),
    'lightning': ('Lightning - yellow', '#EAB308'),
    'water': ('Water - blue', '#3B82F6'),
    'shadow': ('Shadow - purple', '#9855D5'),
    'plant': ('Plant - green', '#22A55A'),
    'metal': ('Metal - bronze or orange', '#B97532'),
}
ORDER = list(PALETTE)[2:]
SOURCES = [
    'muju/src/game/units.ts',
    'muju/src/components/UnitArtwork.tsx',
    'muju/src/components/ElementGlyph.tsx',
    'muju/src/index.css',
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sampled(d):
    points = []
    for seg in parse_path(d):
        # Approximation steps at most 0.20 SVG units (roughly 0.14 mm).
        steps = max(1, math.ceil(seg.length() / .20))
        points.extend((seg.point(i / steps).real, seg.point(i / steps).imag)
                      for i in range(steps))
    end = parse_path(d)[-1].end
    points.append((end.real, end.imag))
    return points


def polygon(d):
    p = Polygon(sampled(d))
    if not p.is_valid:
        # The fire SVG crosses itself by <0.001 square SVG units at its tip.
        # Resolve that tiny crossing to a filled outline, but reject larger changes.
        fixed = p.buffer(0)
        assert abs(fixed.area - p.area) < .02, f'Review self-intersecting SVG: {d}'
        p = fixed
    assert p.is_valid and p.area > 0, f'Invalid source SVG: {d}'
    return p.simplify(.008, preserve_topology=True)


def polygons(p):
    return [p] if p.geom_type == 'Polygon' else list(p.geoms)


def prism(p, bottom, top):
    meshes = []
    for part in polygons(p):
        mesh = trimesh.creation.extrude_polygon(part, top - bottom, engine='earcut')
        mesh.apply_translation([0, 0, bottom])
        meshes.append(mesh)
    return trimesh.util.concatenate(meshes)


def body_mesh(p):
    """Convex body with restrained top and bottom chamfers, no hidden shells."""
    ring = np.asarray(orient(p, sign=1).exterior.coords[:-1])
    assert p.convex_hull.area - p.area < .01
    n = len(ring)
    levels = [(0, .98), (.3, 1), (2.8, 1), (BASE_Z, .975)]
    vertices = [[x * scale, y * scale, z] for z, scale in levels for x, y in ring]
    vertices += [[0, 0, 0], [0, 0, BASE_Z]]
    bottom_center, top_center = 4 * n, 4 * n + 1
    faces = []
    for i in range(n):
        j = (i + 1) % n
        faces += [[bottom_center, j, i], [top_center, 3 * n + i, 3 * n + j]]
        for k in range(3):
            a, b, c, d = k * n + i, k * n + j, (k + 1) * n + j, (k + 1) * n + i
            faces += [[a, b, c], [a, c, d]]
    return trimesh.Trimesh(vertices=vertices, faces=faces, process=True)


def meshes_from_source():
    artwork = (ROOT / SOURCES[1]).read_text()
    glyph_text = (ROOT / SOURCES[2]).read_text()
    units = (ROOT / SOURCES[0]).read_text()
    paths = re.findall(r"[?:]\s*'([^']+)'", artwork.split('const shape = ivory', 1)[1].split('return <svg', 1)[0])
    assert len(paths) == 2, 'Review changed army silhouettes before regenerating.'
    # Guard the presentation transforms and pip rather than silently copying stale geometry.
    assert 'translate(2.4 0) scale(.9)' in artwork
    assert 'y="36" width="3" height="4" rx=".8"' in artwork
    rows = []
    for owner, path in zip(('white', 'black'), paths):
        raw_body = polygon(path)
        x0, y0, x1, y1 = raw_body.bounds
        scale = SIZE / max(x1 - x0, y1 - y0)
        def position(p):
            p = affinity.translate(p, -(x0 + x1) / 2, -(y0 + y1) / 2)
            return affinity.scale(p, xfact=scale, yfact=-scale, origin=(0, 0))
        body = position(raw_body)
        base = body_mesh(body)
        for element in ORDER:
            block = re.search(rf"case '{element}': return (.*?);", glyph_text, re.S).group(1)
            fills, strokes = [], []
            for tag in re.findall(r'<path\b[^>]+/>', block):
                d = re.search(r'd="([^"]+)"', tag).group(1)
                if 'fill="none"' in tag:
                    width = float(re.search(r'strokeWidth="([^"]+)"', tag).group(1))
                    strokes.append(LineString(sampled(d)).buffer(width / 2, quad_segs=12))
                else:
                    fills.append(polygon(d))
            glyph = unary_union(fills)
            if strokes:
                glyph = glyph.difference(unary_union(strokes))
            glyph = affinity.scale(glyph, xfact=.9, yfact=.9, origin=(0, 0))
            glyph = position(affinity.translate(glyph, 2.4, 0))
            # Leave clearance on the rounded body's chamfer (the UI has no such bevel).
            glyph = affinity.scale(glyph, .94, .94, origin=(0, 0))
            # Small inward fillet removes needle tips without adding fine isolated walls.
            glyph = glyph.buffer(-.16, quad_segs=6).buffer(.16, quad_segs=6)
            pip = position(box(23.3, 36.8, 24.7, 39.2).buffer(.8, quad_segs=10))
            details_2d = unary_union([glyph, pip]).simplify(.005, preserve_topology=True)
            outside = details_2d.difference(affinity.scale(body, .975, .975, origin=(0, 0))).area
            assert outside < 1e-6, (owner, element, outside, body.bounds, details_2d.bounds)
            details = prism(details_2d, BASE_Z, TOP_Z)
            fused = trimesh.boolean.union([base, details], engine='manifold')
            unit_block = re.search(r"\{\s*id: '" + element + r"_1',.*?\n  \}", units, re.S).group(0)
            name = re.search(r"name: '([^']+)'", unit_block).group(1)
            assert 'tier: 1' in unit_block
            rows.append(dict(owner=owner, element=element, name=name,
                             key=f'{owner}_{element}_tier1', base=base.copy(),
                             details=details, fused=fused))
    return rows


def q(tag):
    return f'{{{CORE}}}{tag}'


def write_3mf(path, rows, positions):
    """Core 3MF: each build item is a base + relief component assembly."""
    ET.register_namespace('', CORE)
    root = ET.Element(q('model'), {'unit': 'millimeter', '{http://www.w3.org/XML/1998/namespace}lang': 'en-US'})
    ET.SubElement(root, q('metadata'), {'name': 'Title'}).text = path.stem
    ET.SubElement(root, q('metadata'), {'name': 'Description'}).text = 'Muju Tier 1; 30 mm; base 3.2 mm, colored relief 0.8 mm. Assign named materials to actual filament in your slicer.'
    resources = ET.SubElement(root, q('resources'))
    colors = ET.SubElement(resources, q('basematerials'), {'id': '1'})
    for label, hex_color in PALETTE.values():
        ET.SubElement(colors, q('base'), {'name': label, 'displaycolor': hex_color + 'FF'})
    build = ET.SubElement(root, q('build'))
    object_id = 2
    for row, (x, y) in zip(rows, positions):
        components = []
        for part, color_key in [('base', row['owner']), ('details', row['element'])]:
            mesh = row[part]
            obj = ET.SubElement(resources, q('object'), {'id': str(object_id), 'type': 'model',
                'name': f'{row["key"]}_{part} - {PALETTE[color_key][0]}',
                'pid': '1', 'pindex': str(list(PALETTE).index(color_key))})
            shape = ET.SubElement(obj, q('mesh'))
            vertices = ET.SubElement(shape, q('vertices'))
            for v in mesh.vertices:
                ET.SubElement(vertices, q('vertex'), dict(zip(('x', 'y', 'z'), (f'{a:.6f}' for a in v))))
            triangles = ET.SubElement(shape, q('triangles'))
            for face in mesh.faces:
                ET.SubElement(triangles, q('triangle'), dict(zip(('v1', 'v2', 'v3'), map(str, face))))
            components.append(object_id)
            object_id += 1
        obj = ET.SubElement(resources, q('object'), {'id': str(object_id), 'type': 'model',
            'name': f'{row["owner"].title()} {row["name"]} - {row["element"].title()} Tier 1'})
        group = ET.SubElement(obj, q('components'))
        for child in components:
            ET.SubElement(group, q('component'), {'objectid': str(child)})
        ET.SubElement(build, q('item'), {'objectid': str(object_id),
            'transform': f'1 0 0 0 1 0 0 0 1 {x} {y} 0'})
        object_id += 1
    path.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(path, 'w', ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>')
        z.writestr('_rels/.rels', '<?xml version="1.0" encoding="UTF-8"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>')
        z.writestr('3D/3dmodel.model', ET.tostring(root, encoding='utf-8', xml_declaration=True))


def check_mesh(mesh, expected_shells=None):
    assert mesh.is_watertight, 'Open/non-manifold mesh'
    assert mesh.is_winding_consistent and mesh.volume > 0, 'Inverted mesh'
    assert np.isfinite(mesh.vertices).all()
    assert float(mesh.area_faces.min()) > 1e-10, 'Degenerate triangle'
    shells = mesh.split(only_watertight=False)
    assert all(s.is_volume for s in shells), 'Non-solid shell'
    if expected_shells is not None:
        assert len(shells) == expected_shells, (len(shells), expected_shells)
    return dict(watertight=True, consistent_winding=True, shells=len(shells),
                triangles=len(mesh.faces), volume_mm3=round(float(mesh.volume), 3),
                dimensions_mm=np.round(mesh.extents, 4).tolist(),
                z_bounds_mm=np.round(mesh.bounds[:, 2], 4).tolist())


def validate_files(rows):
    report = {'stl': {}, '3mf': {}, 'assembly': {}, 'physical_print_tested': False,
              'slicer_tested': False}
    for path in sorted(OUT.rglob('*.stl')):
        loaded = trimesh.load_mesh(path, process=True)
        expected = 6 if path.parent.name == 'plates' else 1 if path.parent.name == 'stl' or path.stem.endswith('_base') else None
        report['stl'][str(path.relative_to(OUT))] = check_mesh(loaded, expected)
    wrapper = lib3mf.Wrapper()
    for path in sorted(OUT.rglob('*.3mf')):
        model = wrapper.CreateModel()
        reader = model.QueryReader('3mf')
        reader.SetStrictModeActive(True)
        reader.ReadFromFile(str(path))
        assert reader.GetWarningCount() == 0, str(path)
        # Independently re-load serialized geometry and properties, not only in-memory meshes.
        with ZipFile(path) as z:
            root = ET.fromstring(z.read('3D/3dmodel.model'))
        assert root.attrib['unit'] == 'millimeter'
        mesh_count = 0
        for obj in root.findall(f'{q("resources")}/{q("object")}'):
            shape = obj.find(q('mesh'))
            if shape is None:
                continue
            verts = [[float(v.get(a)) for a in ('x', 'y', 'z')] for v in shape.find(q('vertices'))]
            faces = [[int(t.get(a)) for a in ('v1', 'v2', 'v3')] for t in shape.find(q('triangles'))]
            check_mesh(trimesh.Trimesh(vertices=verts, faces=faces, process=True))
            assert obj.get('pid') == '1' and 0 <= int(obj.get('pindex')) < len(PALETTE)
            mesh_count += 1
        items = len(root.find(q('build')))
        assert mesh_count == 2 * items
        report['3mf'][str(path.relative_to(OUT))] = dict(strict_lib3mf_read=True, warnings=0, build_items=items, solid_parts=mesh_count, units='millimeter')
    for row in rows:
        base, details, fused = (row[k] for k in ('base', 'details', 'fused'))
        assert abs(base.bounds[1, 2] - BASE_Z) < 1e-6
        assert abs(details.bounds[0, 2] - BASE_Z) < 1e-6
        assert abs(fused.bounds[0, 2]) < 1e-6 and abs(fused.bounds[1, 2] - TOP_Z) < 1e-6
        # The two materials meet only on the top plane; no volumetric overlap or air gap.
        assert abs(base.volume + details.volume - fused.volume) < .002
        check_mesh(fused, 1)
        # Every horizontal section through material has only closed loops.
        slice_count = 0
        for height in np.arange(.1, TOP_Z, .2):
            section = fused.section(plane_origin=[0, 0, height], plane_normal=[0, 0, 1])
            assert section is not None and section.is_closed
            slice_count += 1
        report['assembly'][row['key']] = dict(single_connected_solid=True, flat_bottom=True,
            closed_horizontal_sections=slice_count, material_interface_mm=BASE_Z, overlapping_material_volume_mm3=0)
    (HERE / 'validation.json').write_text(json.dumps(report, indent=2) + '\n')
    return report


def main():
    rows = meshes_from_source()
    for directory in ('stl', 'parts', '3mf', 'plates', 'element-pairs'):
        (OUT / directory).mkdir(parents=True, exist_ok=True)
    for row in rows:
        row['fused'].export(OUT / 'stl' / f'{row["key"]}.stl')
        for part in ('base', 'details'):
            row[part].export(OUT / 'parts' / f'{row["key"]}_{part}.stl')
        write_3mf(OUT / '3mf' / f'{row["key"]}.3mf', [row], [(20, 20)])
    for owner in ('white', 'black'):
        army = [r for r in rows if r['owner'] == owner]
        positions = [(20 + 36 * (i % 3), 56 - 36 * (i // 3)) for i in range(6)]
        write_3mf(OUT / 'plates' / f'{owner}_six_elements.3mf', army, positions)
        combined = []
        for row, (x, y) in zip(army, positions):
            mesh = row['fused'].copy()
            mesh.apply_translation([x, y, 0])
            combined.append(mesh)
        trimesh.util.concatenate(combined).export(OUT / 'plates' / f'{owner}_six_elements.stl')
    for element in ORDER:
        pair = [r for r in rows if r['element'] == element]
        write_3mf(OUT / 'element-pairs' / f'{element}_white_and_black.3mf', pair, [(20, 20), (56, 20)])
    positions = [(20 + 36 * (i % 6), 56 - 36 * (i // 6)) for i in range(12)]
    write_3mf(OUT / 'plates' / 'all_12_tokens.3mf', rows, positions)
    report = validate_files(rows)
    manifest = dict(title='Muju Tier 1 - colored raised-art tokens',
        source_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        sources={p: digest(ROOT / p) for p in SOURCES},
        design=dict(maximum_body_span_mm=SIZE, base_height_mm=BASE_Z, relief_height_mm=TOP_Z - BASE_Z,
                    total_height_mm=TOP_Z, glyph_corner_radius_mm=.16, glyph_print_fit_scale=.94,
                    leaf_vein='Open groove through colored relief only',
                    tier_pips=1, supports='Not required by geometry: flat base and supported relief',
                    color_strategy='White/black base; element-colored symbol and Tier 1 pip'),
        palette={key: {'label': label, 'hex': color} for key, (label, color) in PALETTE.items()},
        tokens=[{k: r[k] for k in ('owner', 'element', 'name', 'key')} for r in rows],
        files={str(p.relative_to(HERE)): digest(p) for p in sorted(OUT.rglob('*')) if p.is_file()},
        verification={'stl_count': len(report['stl']), 'three_mf_count': len(report['3mf']),
                      'physical_print_tested': False, 'slicer_tested': False})
    (HERE / 'manifest.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
    print(f'Generated and verified {len(rows)} tokens, {len(report["stl"])} STLs and {len(report["3mf"])} 3MF files.')


if __name__ == '__main__':
    main()
