import { upkeepDue } from '../game/upkeep';
import type { GameState, PlayerId, Unit, Position } from '../game/types';
import type { EvaluationWeights } from './types';
import { DEFAULT_WEIGHTS } from './types';
import { getPlayerUnits } from '../game/board';
import { getUnitDefinition } from '../game/units';
import { getValidMoves } from '../game/movement';
import {
  getValidAttacks,
  canBeEliminated,
  getAttackersFor,
  canBeEliminatedByCombined,
} from '../game/combat';
import { canMine } from '../game/mining';
import { getAllSpawnPositions } from '../game/spawning';
import { getGameResult, homeOccupationPressure } from '../game/victory';

/**
 * Large value for winning positions
 */
const VICTORY_SCORE = 100000;

/**
 * Evaluate board position from a player's perspective
 * Positive = good for player, negative = bad for player
 */
export function evaluatePosition(
  state: GameState,
  forPlayer: PlayerId,
  weights: EvaluationWeights = DEFAULT_WEIGHTS
): number {
  // Check for victory conditions first
  const victory = getGameResult(state);
  if (victory.status === 'draw') return 0;
  if (victory.status === 'victory') {
    return victory.winner === forPlayer ? VICTORY_SCORE : -VICTORY_SCORE;
  }

  const opponent: PlayerId = forPlayer === 'white' ? 'black' : 'white';

  // Occupation is a threat, not a win. Verified reply-turn proofs are injected
  // by the tactical service; keep the static corner prior modest.
  let score = 0.08 * homeOccupationPressure(state, forPlayer);

  // Unit value (based on cost/tier)
  score += weights.unitValue * (
    calculateUnitValue(state, forPlayer) -
    calculateUnitValue(state, opponent)
  );

  // Resource advantage
  score += weights.resourceAdvantage * (
    state.players[forPlayer].resources -
    state.players[opponent].resources
  );

  // Territory control (spawn zones)
  score += weights.territoryControl * (
    calculateTerritoryControl(state, forPlayer) -
    calculateTerritoryControl(state, opponent)
  );

  // Mining potential
  score += weights.miningPotential * (
    calculateMiningPotential(state, forPlayer) -
    calculateMiningPotential(state, opponent)
  );

  // Threat level (units threatening enemy)
  score += weights.threatLevel * (
    calculateThreatLevel(state, forPlayer) -
    calculateThreatLevel(state, opponent)
  );

  // Mobility (optionality - number of possible actions)
  score += weights.mobility * (
    calculateMobility(state, forPlayer) -
    calculateMobility(state, opponent)
  );

  // Center control
  score += weights.centerControl * (
    calculateCenterControl(state, forPlayer) -
    calculateCenterControl(state, opponent)
  );

  // Unit health (defense-weighted)
  score += weights.unitHealth * (
    calculateUnitHealth(state, forPlayer) -
    calculateUnitHealth(state, opponent)
  );

  // Kill threats received
  score += weights.killThreatsReceived * (
    calculateKillThreatsReceived(state, forPlayer) -
    calculateKillThreatsReceived(state, opponent)
  );

  // Combined attack potential
  score += weights.combinedAttackPotential * (
    calculateCombinedAttackPotential(state, forPlayer) -
    calculateCombinedAttackPotential(state, opponent)
  );

  // Spawn denial pressure
  score += weights.spawnDenialPressure * (
    calculateSpawnDenialPressure(state, forPlayer) -
    calculateSpawnDenialPressure(state, opponent)
  );

  // Spawn infiltration
  score += weights.spawnInfiltration * (
    calculateSpawnInfiltration(state, forPlayer) -
    calculateSpawnInfiltration(state, opponent)
  );

  // Queue value
  score += weights.queueValue * (
    calculateQueueValue(state, forPlayer) -
    calculateQueueValue(state, opponent)
  );

  // Step efficiency
  score += weights.stepEfficiency * (
    calculateStepEfficiency(state, forPlayer) -
    calculateStepEfficiency(state, opponent)
  );

  // Tech tree progress
  score += weights.techTreeProgress * (
    calculateTechTreeProgress(state, forPlayer) -
    calculateTechTreeProgress(state, opponent)
  );

  return score;
}

/**
 * Calculate total unit value based on cost
 */
function calculateUnitValue(state: GameState, player: PlayerId): number {
  const units = getPlayerUnits(state.board, player);
  return units.reduce((total, unit) => {
    const def = getUnitDefinition(unit.definitionId);
    return total + def.cost;
  }, 0);
}

/**
 * Calculate territory control (number of spawn positions available)
 */
function calculateTerritoryControl(state: GameState, player: PlayerId): number {
  const spawnPositions = getAllSpawnPositions(player, state.board);
  return spawnPositions.length;
}

/**
 * Calculate mining potential (units that can mine * available resources)
 */
function calculateMiningPotential(state: GameState, player: PlayerId): number {
  const units = getPlayerUnits(state.board, player);
  let potential = 0;

  for (const unit of units) {
    if (canMine(unit, state.board)) {
      const def = getUnitDefinition(unit.definitionId);
      potential += def.mining; // Mining power as potential
    }
  }

  return potential;
}

/**
 * Calculate threat level (units adjacent to enemies that can kill)
 */
function calculateThreatLevel(state: GameState, player: PlayerId): number {
  const units = getPlayerUnits(state.board, player);
  let threats = 0;

  for (const unit of units) {
    const attacks = getValidAttacks(unit, state.board);
    for (const targetPos of attacks) {
      const target = state.board.units.find(
        (u) => u.position.x === targetPos.x && u.position.y === targetPos.y
      );
      if (target && canBeEliminated(target, unit)) {
        threats += getUnitDefinition(target.definitionId).cost; // Value of killable target
      }
    }
  }

  return threats;
}

/**
 * Calculate mobility (optionality - total number of valid moves)
 * This is a key metric for strategic AI - more options = better position
 */
function calculateMobility(state: GameState, player: PlayerId): number {
  const units = getPlayerUnits(state.board, player);
  let mobility = 0;

  for (const unit of units) {
    // Count valid moves
    const moves = getValidMoves(unit, state.board);
    mobility += moves.length;

    // Count valid attacks (weighted higher)
    const attacks = getValidAttacks(unit, state.board);
    mobility += attacks.length * 1.5;

    // Mining capability
    if (canMine(unit, state.board)) {
      mobility += 1;
    }
  }

  return mobility;
}

/**
 * Calculate center control (units near center of board)
 * Center positions are strategically valuable
 */
function calculateCenterControl(state: GameState, player: PlayerId): number {
  const units = getPlayerUnits(state.board, player);
  const center = { x: 4.5, y: 4.5 };
  let control = 0;

  for (const unit of units) {
    // Distance from center (max ~6.4, min 0)
    const distance = Math.sqrt(
      Math.pow(unit.position.x - center.x, 2) +
      Math.pow(unit.position.y - center.y, 2)
    );
    // Convert to score (closer = better)
    control += Math.max(0, 7 - distance);
  }

  return control;
}

/**
 * Calculate unit health (sum of defense values)
 */
function calculateUnitHealth(state: GameState, player: PlayerId): number {
  const units = getPlayerUnits(state.board, player);
  return units.reduce((total, unit) => {
    const def = getUnitDefinition(unit.definitionId);
    return total + def.defense;
  }, 0);
}

function calculateKillThreatsReceived(state: GameState, player: PlayerId): number {
  const units = getPlayerUnits(state.board, player);
  let threats = 0;

  for (const unit of units) {
    const attackers = getAttackersFor(unit.position, state.board, getOpponent(player));
    for (const attacker of attackers) {
      if (canBeEliminated(unit, attacker)) {
        threats += getUnitDefinition(unit.definitionId).cost;
        break;
      }
    }
  }

  return threats;
}

function calculateCombinedAttackPotential(state: GameState, player: PlayerId): number {
  const enemyUnits = getPlayerUnits(state.board, getOpponent(player));
  let potential = 0;

  for (const enemy of enemyUnits) {
    const attackers = getAttackersFor(enemy.position, state.board, player);
    if (attackers.length < 2) continue;
    if (canBeEliminatedByCombined(enemy, attackers)) {
      potential += getUnitDefinition(enemy.definitionId).cost;
    }
  }

  return potential;
}

function calculateSpawnDenialPressure(state: GameState, player: PlayerId): number {
  const spawnPositions = getAllSpawnPositions(player, state.board);
  const opponentUnits = getPlayerUnits(state.board, getOpponent(player));
  let pressure = 0;

  for (const unit of opponentUnits) {
    if (spawnPositions.some((pos) => pos.x === unit.position.x && pos.y === unit.position.y)) {
      pressure += 1;
    }
  }

  return pressure;
}

function calculateSpawnInfiltration(state: GameState, player: PlayerId): number {
  const spawnPositions = getAllSpawnPositions(getOpponent(player), state.board);
  const units = getPlayerUnits(state.board, player);
  let infiltration = 0;

  for (const unit of units) {
    if (spawnPositions.some((pos) => pos.x === unit.position.x && pos.y === unit.position.y)) {
      infiltration += 1;
    }
  }

  return infiltration;
}

function calculateQueueValue(state: GameState, player: PlayerId): number {
  const queue = state.players[player].buildQueue;
  let value = 0;
  for (const queuedUnit of queue) {
    const def = getUnitDefinition(queuedUnit.definitionId);
    const discount = Math.pow(0.9, queuedUnit.turnsRemaining);
    value += def.cost * discount;
  }
  return value;
}

function calculateStepEfficiency(state: GameState, player: PlayerId): number {
  if (state.turn.currentPlayer !== player || state.turn.phase !== 'action') {
    return 0;
  }

  const units = getPlayerUnits(state.board, player);
  const activeUnits = units.filter((unit) => unit.canActThisTurn).length;
  return Math.min(activeUnits, state.turn.actionsRemaining);
}

function calculateTechTreeProgress(state: GameState, player: PlayerId): number {
  const units = getPlayerUnits(state.board, player);
  let progress = 0;
  const tiers = new Set<number>();

  for (const unit of units) {
    const def = getUnitDefinition(unit.definitionId);
    tiers.add(def.tier);
  }

  for (const tier of tiers) if (tier > 1) progress += 1;

  return progress;
}

function getOpponent(player: PlayerId): PlayerId {
  return player === 'white' ? 'black' : 'white';
}

/**
 * Quick evaluation for leaf nodes (faster, less accurate)
 */
export function quickEvaluate(state: GameState, forPlayer: PlayerId): number {
  const victory = getGameResult(state);
  if (victory.status === 'draw') return 0;
  if (victory.status === 'victory') {
    return victory.winner === forPlayer ? VICTORY_SCORE : -VICTORY_SCORE;
  }

  const opponent: PlayerId = forPlayer === 'white' ? 'black' : 'white';

  // Just unit value difference
  return calculateUnitValue(state, forPlayer) - calculateUnitValue(state, opponent) + 0.08 * homeOccupationPressure(state, forPlayer);
}

/**
 * Evaluate a single unit's position value
 */
export function evaluateUnitPosition(unit: Unit, state: GameState): number {
  const def = getUnitDefinition(unit.definitionId);
  let value = def.cost;

  // Bonus for mobility
  const moves = getValidMoves(unit, state.board);
  value += moves.length * 0.1;

  // Bonus for threat
  const attacks = getValidAttacks(unit, state.board);
  value += attacks.length * 0.2;

  // Bonus for center position
  const center = { x: 4.5, y: 4.5 };
  const distance = Math.sqrt(
    Math.pow(unit.position.x - center.x, 2) +
    Math.pow(unit.position.y - center.y, 2)
  );
  value += Math.max(0, (7 - distance) * 0.1);

  return value;
}

/**
 * Get a heuristic score for an action (for move ordering)
 */
export function scoreAction(
  action: { type: string; unitId?: string; targetPosition?: Position },
  state: GameState
): number {
  switch (action.type) {
    case 'ATTACK':
      // Score attacks by target value
      if (action.targetPosition) {
        const target = state.board.units.find(
          (u) =>
            u.position.x === action.targetPosition!.x &&
            u.position.y === action.targetPosition!.y
        );
        if (target) {
          const targetDef = getUnitDefinition(target.definitionId);
          return 100 + targetDef.cost; // High priority for kills
        }
      }
      return 100;

    case 'MINE':
      return 50; // Medium priority

    case 'MOVE':
      return 25; // Lower priority

    default:
      return 0;
  }
}

/**
 * Check if a player should consider resigning
 * Returns true if the position is hopeless
 */
export function shouldResign(state: GameState, player: PlayerId): boolean {
  // Material ratios cannot prove defeat when an invasion can still win.
  if (state.victoryRule !== 'elimination') return false;
  const opponent: PlayerId = player === 'white' ? 'black' : 'white';

  // Get unit values
  const playerValue = calculateUnitValue(state, player);
  const opponentValue = calculateUnitValue(state, opponent);

  // If player has no units, they've already lost (don't need resignation)
  if (playerValue === 0) return false;

  // A banked economy or ready reinforcements can reverse a board deficit.
  // Only inspect our own private assets; opponent queues remain hidden.
  if (state.players[player].resources > upkeepDue(state,player) || state.players[player].buildQueue.length > 0) return false;
  if (generateWinningAttack(state, player)) return false;

  // If opponent has 3x or more unit value, consider resigning
  if (opponentValue >= playerValue * 3) {
    return true;
  }

  // If player only has 1 unit and opponent has 3+
  const playerUnits = getPlayerUnits(state.board, player);
  const opponentUnits = getPlayerUnits(state.board, opponent);

  if (playerUnits.length === 1 && opponentUnits.length >= 3) {
    // And the player's unit is lower tier
    const playerMaxTier = Math.max(
      ...playerUnits.map((u) => getUnitDefinition(u.definitionId).tier)
    );
    const opponentMaxTier = Math.max(
      ...opponentUnits.map((u) => getUnitDefinition(u.definitionId).tier)
    );

    if (opponentMaxTier > playerMaxTier) {
      return true;
    }
  }

  return false;
}

function generateWinningAttack(state: GameState, player: PlayerId): boolean {
  if (state.turn.currentPlayer !== player || state.turn.phase !== 'action' || state.turn.actionsRemaining <= 0) return false;
  const enemies = getPlayerUnits(state.board, player === 'white' ? 'black' : 'white');
  return enemies.length === 1 && getPlayerUnits(state.board, player).some(u =>
    getValidAttacks(u, state.board).some(p => p.x === enemies[0].position.x && p.y === enemies[0].position.y) && canBeEliminated(enemies[0], u));
}
